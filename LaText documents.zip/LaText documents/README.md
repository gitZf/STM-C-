The LaText used resource are store in this directory.
