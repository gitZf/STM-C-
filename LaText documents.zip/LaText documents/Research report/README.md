Research report resources due 06/11/2017

Research Report<br>
The research report should have the following sections:<br>
Abstract;<br>
Table of Contents;<br>
Introduction;<br>
Overview of areas, technologies or topics researched;<br>
For each area, technology or topic:<br>
reasons for researching and perceived relevance to project;<br>
what you discovered during research;<br>
utility of the research and any further research it suggested;<br>
Summary and Conclusions;<br>
Detailed algorithm descriptions that you plan to implement;<br>
Glossary;<br>
Bibliography.<br>
