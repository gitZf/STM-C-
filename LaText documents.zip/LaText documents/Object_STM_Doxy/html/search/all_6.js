var searchData=
[
  ['increase_5fversionnumber',['increase_VersionNumber',['../class_o_s_t_m.html#a5f90caa4384d371c16b7cac860d9f89a',1,'OSTM']]],
  ['instance',['Instance',['../class_t_m.html#a7ce5f35e0dae76df4fe116cf905bbe60',1,'TM']]],
  ['is_5fabort_5ftransaction',['Is_Abort_Transaction',['../class_o_s_t_m.html#afc2851abf5342c3c67342c2c14820115',1,'OSTM']]],
  ['is_5fcan_5fcommit',['Is_Can_Commit',['../class_o_s_t_m.html#a8df39ced3b401aa466df97e26d14b1b7',1,'OSTM']]],
  ['is_5flocked',['is_Locked',['../class_o_s_t_m.html#afb6520023ed2c4a6188b688c46f192d0',1,'OSTM']]]
];
