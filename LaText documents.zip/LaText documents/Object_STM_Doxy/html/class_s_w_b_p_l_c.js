var class_s_w_b_p_l_c =
[
    [ "SWBPLC", "class_s_w_b_p_l_c.html#a320f4e2b023038668d941ce5d0c46aeb", null ],
    [ "SWBPLC", "class_s_w_b_p_l_c.html#a29c408f7ccb7c5962dab8ac858758a89", null ],
    [ "SWBPLC", "class_s_w_b_p_l_c.html#a33e460bff6f51b30209a6f5a25a24d7d", null ],
    [ "SWBPLC", "class_s_w_b_p_l_c.html#a767c6ae2b15f523b5ec6e35e137dcc96", null ],
    [ "~SWBPLC", "class_s_w_b_p_l_c.html#a5d6f00a76145f32424ff6db9ac23c6fe", null ],
    [ "copy", "class_s_w_b_p_l_c.html#a9468640482a6cfb9bfb4115fc59191d5", null ],
    [ "GetAccountNumber", "class_s_w_b_p_l_c.html#a1a997f6d333e5021970e50605431d7df", null ],
    [ "GetAddress", "class_s_w_b_p_l_c.html#a3a62a57b3ecdd06ed977ef372dab89ad", null ],
    [ "GetBalance", "class_s_w_b_p_l_c.html#af7f5f662ab926bfb9c0c1c7156cde24c", null ],
    [ "getBaseCopy", "class_s_w_b_p_l_c.html#a77f0e0d6c08a95066d277bf6b2073a5c", null ],
    [ "GetFirstName", "class_s_w_b_p_l_c.html#ace6bbcd6546896e581e3a2ee9504d090", null ],
    [ "GetFullname", "class_s_w_b_p_l_c.html#adb74b3cbc40a401bf7ca4dfb5269c336", null ],
    [ "GetLastName", "class_s_w_b_p_l_c.html#a72b2595acea28dae9e4f5816dd3c4652", null ],
    [ "operator=", "class_s_w_b_p_l_c.html#a1e4b8f85d4e8e29429d691e258fea2e7", null ],
    [ "SetAccountNumber", "class_s_w_b_p_l_c.html#a45eb1e6a73fde0dc00824319d4e0b81a", null ],
    [ "SetAddress", "class_s_w_b_p_l_c.html#a99590e47dda8361b2d5869fd315f92f8", null ],
    [ "SetBalance", "class_s_w_b_p_l_c.html#a9a0d94da8922f00ca4a3e5fa774e8b3f", null ],
    [ "SetFirstName", "class_s_w_b_p_l_c.html#a8146eabca4648ef679188904f677df9d", null ],
    [ "SetFullname", "class_s_w_b_p_l_c.html#a09376d46475bbceda897948714ff1e72", null ],
    [ "SetLastName", "class_s_w_b_p_l_c.html#aa5581ea5d2e0315b816876737e887f09", null ],
    [ "toString", "class_s_w_b_p_l_c.html#a761c77b5a204b4ae05ffb01bd602c3c2", null ]
];