var class_u_n_b_l =
[
    [ "UNBL", "class_u_n_b_l.html#aa264ef64c453e6049b3d4c984d84d1de", null ],
    [ "UNBL", "class_u_n_b_l.html#a9afc7728e8d9970b63592af018a2afb8", null ],
    [ "UNBL", "class_u_n_b_l.html#abbd578fbd58cf6f2143f17b3011f6c21", null ],
    [ "UNBL", "class_u_n_b_l.html#aca7a99d7308d5d8dd5841a0eeeed0852", null ],
    [ "~UNBL", "class_u_n_b_l.html#a32d405e6e9adfab1ffdeec6406f9e72f", null ],
    [ "copy", "class_u_n_b_l.html#a14d5e1adc618827667d8d9524abaf31b", null ],
    [ "GetAccountNumber", "class_u_n_b_l.html#a44a84fb7fe8778e3048921581049c715", null ],
    [ "GetAddress", "class_u_n_b_l.html#a74f8896be6e93ad8f89ca3b0da83525a", null ],
    [ "GetBalance", "class_u_n_b_l.html#ad5b882bff8d1e2619b2ebbd170345c99", null ],
    [ "getBaseCopy", "class_u_n_b_l.html#a5dfe7f9e5fbb66abff9a73e40e803887", null ],
    [ "GetFirstName", "class_u_n_b_l.html#ae89215b95f2e11aa70f9c8bbfd55c10c", null ],
    [ "GetFullname", "class_u_n_b_l.html#a4292e9cafc42be3d9f4f3d6221bc9638", null ],
    [ "GetLastName", "class_u_n_b_l.html#a27f19f2af5e1abd33b5c63f16b493f6c", null ],
    [ "operator=", "class_u_n_b_l.html#a32ab1105494f18bdb33e651e9bbfcd02", null ],
    [ "SetAccountNumber", "class_u_n_b_l.html#a0ee536d872c0f93486f942b268c2431e", null ],
    [ "SetAddress", "class_u_n_b_l.html#acbd63767c5070d82605671cfce0433a9", null ],
    [ "SetBalance", "class_u_n_b_l.html#a3b7b2089cf4e2995e99b860b1fb2e5cb", null ],
    [ "SetFirstName", "class_u_n_b_l.html#aef061d2cba01bcd752e9305dc374cabc", null ],
    [ "SetFullname", "class_u_n_b_l.html#a1b3f52c44756930c1ee4acb06f2634ad", null ],
    [ "SetLastName", "class_u_n_b_l.html#abd683db339dffe71af3993a8a5cb5929", null ],
    [ "toString", "class_u_n_b_l.html#a76d8bba21d64d79d8de63763b8acc1fd", null ]
];