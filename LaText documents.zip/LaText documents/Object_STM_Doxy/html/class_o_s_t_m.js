var class_o_s_t_m =
[
    [ "OSTM", "class_o_s_t_m.html#a968edf778668bd0ec7603f0571619196", null ],
    [ "OSTM", "class_o_s_t_m.html#a2314f55a127b94aa8a51d19ba798401e", null ],
    [ "~OSTM", "class_o_s_t_m.html#a30a17d73d0259c60eeab72d6dfa9ceb1", null ],
    [ "copy", "class_o_s_t_m.html#a535d90fced5adbb70312c92f3778e08d", null ],
    [ "Get_Unique_ID", "class_o_s_t_m.html#a5a01a8b98d16b1d1904ecf9356e7b71d", null ],
    [ "Get_Version", "class_o_s_t_m.html#a1f1db9d482f22c8e7caa17dfb340626b", null ],
    [ "getBaseCopy", "class_o_s_t_m.html#a0bfa3763bd441407dd6365f42714f94c", null ],
    [ "increase_VersionNumber", "class_o_s_t_m.html#a5f90caa4384d371c16b7cac860d9f89a", null ],
    [ "Is_Abort_Transaction", "class_o_s_t_m.html#afc2851abf5342c3c67342c2c14820115", null ],
    [ "Is_Can_Commit", "class_o_s_t_m.html#a8df39ced3b401aa466df97e26d14b1b7", null ],
    [ "is_Locked", "class_o_s_t_m.html#afb6520023ed2c4a6188b688c46f192d0", null ],
    [ "lock_Mutex", "class_o_s_t_m.html#af192c598a3c647f37aaba5757e60240f", null ],
    [ "Set_Abort_Transaction", "class_o_s_t_m.html#aba384cf65c5f56f5b86833730c3c6ea4", null ],
    [ "Set_Can_Commit", "class_o_s_t_m.html#a813ee61c9d1c83c6a6ae30d12aca8a5d", null ],
    [ "Set_Unique_ID", "class_o_s_t_m.html#ab5019a32185631c08abbf826422f2d93", null ],
    [ "Set_Version", "class_o_s_t_m.html#a9529ad8d6d28c1f0cc9b86ed91df1ae1", null ],
    [ "toString", "class_o_s_t_m.html#a513396a115f2987fd07c203309ae8a59", null ],
    [ "unlock_Mutex", "class_o_s_t_m.html#a6cd703bc26c719fd95b4f5362d050762", null ]
];