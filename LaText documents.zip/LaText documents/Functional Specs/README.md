Functional Specs resources due 13/11/2017

Functional Specification<br>
  Define the Application.<br>
  What is the application supposed to be?<br>
  What the product is.<br>
  What is the application supposed to do?<br>
  Usually a small number of core pieces of functionality and a larger number of less important functions;<br>
  List all functionality- re arrange with most important first.<br>
  Who is going to be using this application?<br>
  Identify the user group(s).<br>
  Metrics<br>
  How will you (and we) gauge if your project is successful.<br>
  Is there a precedent for this application? (your inspiration):<br>
  Is it similar to something already in existence?<br>
  How does it differ?<br>
